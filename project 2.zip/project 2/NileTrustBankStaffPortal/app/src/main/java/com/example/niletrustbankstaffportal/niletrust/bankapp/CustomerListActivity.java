package com.niletrust.bankapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.niletrust.bankapp.adapters.CustomerAdapter;
import com.niletrust.bankapp.models.Customer;
import java.util.ArrayList;
import java.util.List;

public class CustomerListActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private TextInputEditText etSearch;
    private RecyclerView recyclerView;
    private TextView tvEmptyState;
    private FloatingActionButton fabRegister;
    private DatabaseHelper dbHelper;
    private CustomerAdapter adapter;
    private List<Customer> customerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_list);

        dbHelper = new DatabaseHelper(this);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Registered Customers");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        etSearch = findViewById(R.id.etSearch);
        recyclerView = findViewById(R.id.recyclerViewCustomers);
        tvEmptyState = findViewById(R.id.tvEmptyState);
        fabRegister = findViewById(R.id.fabRegister);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        customerList = new ArrayList<>();

        adapter = new CustomerAdapter(customerList, customer -> {
            Intent intent = new Intent(CustomerListActivity.this, CustomerDetailsActivity.class);
            intent.putExtra("CUSTOMER_ID", customer.getCustomerId());
            intent.putExtra("ACCOUNT_ID", customer.getAccountId());
            startActivity(intent);
        });
        recyclerView.setAdapter(adapter);

        fabRegister.setOnClickListener(v -> startActivity(new Intent(CustomerListActivity.this, RegisterCustomerActivity.class)));

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterCustomers(s.toString().trim());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadCustomers("");
    }

    private void loadCustomers(String query) {
        customerList.clear();
        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String sql = "SELECT c.customer_id, c.national_id, c.full_name, c.age, c.phone_number, c.address, " +
                    "a.account_id, a.account_number, a.account_type, a.balance, a.status " +
                    "FROM customer c JOIN account a ON c.customer_id = a.customer_id";

            Cursor cursor;
            if (query.isEmpty()) {
                cursor = db.rawQuery(sql, null);
            } else {
                sql += " WHERE c.full_name LIKE ? OR a.account_number LIKE ?";
                String searchPattern = "%" + query + "%";
                cursor = db.rawQuery(sql, new String[]{searchPattern, searchPattern});
            }

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    int cId = cursor.getInt(0);
                    String natId = cursor.getString(1);
                    String name = cursor.getString(2);
                    int age = cursor.getInt(3);
                    String phone = cursor.getString(4);
                    String addr = cursor.getString(5);
                    int accId = cursor.getInt(6);
                    String accNo = cursor.getString(7);
                    String accType = cursor.getString(8);
                    double bal = cursor.getDouble(9);
                    String status = cursor.getString(10);

                    customerList.add(new Customer(cId, accId, natId, name, age, phone, addr, accNo, accType, bal, status));
                } while (cursor.moveToNext());
                cursor.close();
            }

            if (customerList.isEmpty()) {
                tvEmptyState.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
            } else {
                tvEmptyState.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
            }

            adapter.updateList(customerList);
        } catch (Exception e) {
            Toast.makeText(this, "Error loading customers", Toast.LENGTH_SHORT).show();
        }
    }

    private void filterCustomers(String query) {
        loadCustomers(query);
    }
}