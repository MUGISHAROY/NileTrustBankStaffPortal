package com.niletrust.bankapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RegisterCustomerActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private TextInputLayout tilNatId, tilName, tilAge, tilPhone, tilAddress, tilDeposit;
    private TextInputEditText etNatId, etName, etAge, etPhone, etAddress, etDeposit;
    private AutoCompleteTextView actAccountType;
    private Button btnSave;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_customer);

        dbHelper = new DatabaseHelper(this);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Register Customer");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        tilNatId = findViewById(R.id.tilNatId);
        tilName = findViewById(R.id.tilName);
        tilAge = findViewById(R.id.tilAge);
        tilPhone = findViewById(R.id.tilPhone);
        tilAddress = findViewById(R.id.tilAddress);
        tilDeposit = findViewById(R.id.tilDeposit);

        etNatId = findViewById(R.id.etNatId);
        etName = findViewById(R.id.etName);
        etAge = findViewById(R.id.etAge);
        etPhone = findViewById(R.id.etPhone);
        etAddress = findViewById(R.id.etAddress);
        etDeposit = findViewById(R.id.etDeposit);
        actAccountType = findViewById(R.id.actAccountType);
        btnSave = findViewById(R.id.btnSaveCustomer);

        String[] accountTypes = new String[]{"Savings", "Current"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, accountTypes);
        actAccountType.setAdapter(adapter);
        actAccountType.setText("Savings", false);

        btnSave.setOnClickListener(v -> saveCustomer());
    }

    private void saveCustomer() {
        String natId = etNatId.getText() != null ? etNatId.getText().toString().trim().toUpperCase() : "";
        String name = etName.getText() != null ? etName.getText().toString().trim() : "";
        String ageStr = etAge.getText() != null ? etAge.getText().toString().trim() : "";
        String phone = etPhone.getText() != null ? etPhone.getText().toString().trim() : "";
        String address = etAddress.getText() != null ? etAddress.getText().toString().trim() : "";
        String depositStr = etDeposit.getText() != null ? etDeposit.getText().toString().trim() : "";
        String accType = actAccountType.getText().toString();

        boolean hasError = false;

        if (natId.isEmpty()) {
            tilNatId.setError("National ID is required");
            hasError = true;
        } else if (!natId.matches("^[A-Z0-9]{14}$")) {
            tilNatId.setError("Must be exactly 14 alphanumeric characters");
            hasError = true;
        } else {
            tilNatId.setError(null);
        }

        if (name.isEmpty()) {
            tilName.setError("Full name is required");
            hasError = true;
        } else if (!name.matches("^[a-zA-Z\\s]{3,}$")) {
            tilName.setError("Letters and spaces only, at least 3 characters");
            hasError = true;
        } else {
            tilName.setError(null);
        }

        int age = 0;
        if (ageStr.isEmpty()) {
            tilAge.setError("Age is required");
            hasError = true;
        } else {
            try {
                age = Integer.parseInt(ageStr);
                if (age < 18 || age > 100) {
                    tilAge.setError("Age must be between 18 and 100");
                    hasError = true;
                } else {
                    tilAge.setError(null);
                }
            } catch (NumberFormatException e) {
                tilAge.setError("Invalid age");
                hasError = true;
            }
        }

        if (phone.isEmpty()) {
            tilPhone.setError("Phone number is required");
            hasError = true;
        } else if (!phone.matches("^(07\\d{8}|\\+2567\\d{8})$")) {
            tilPhone.setError("Format: 07XXXXXXXX or +2567XXXXXXXX");
            hasError = true;
        } else {
            tilPhone.setError(null);
        }

        if (address.isEmpty()) {
            tilAddress.setError("Physical address is required");
            hasError = true;
        } else {
            tilAddress.setError(null);
        }

        double initialDeposit = 0;
        if (depositStr.isEmpty()) {
            tilDeposit.setError("Initial deposit is required");
            hasError = true;
        } else {
            try {
                initialDeposit = Double.parseDouble(depositStr);
                if (initialDeposit < 10000) {
                    tilDeposit.setError("Minimum initial deposit is UGX 10,000");
                    hasError = true;
                } else {
                    tilDeposit.setError(null);
                }
            } catch (NumberFormatException e) {
                tilDeposit.setError("Invalid amount");
                hasError = true;
            }
        }

        if (hasError) return;

        btnSave.setEnabled(false);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            // Check duplicate National ID
            Cursor cCheck = db.rawQuery("SELECT customer_id FROM customer WHERE national_id = ?", new String[]{natId});
            if (cCheck != null && cCheck.moveToFirst()) {
                cCheck.close();
                tilNatId.setError("National ID already exists in system");
                btnSave.setEnabled(true);
                db.endTransaction();
                return;
            }
            if (cCheck != null) cCheck.close();

            // Insert customer
            ContentValues cvCust = new ContentValues();
            cvCust.put("national_id", natId);
            cvCust.put("full_name", name);
            cvCust.put("age", age);
            cvCust.put("phone_number", phone);
            cvCust.put("address", address);
            long customerId = db.insert(DatabaseHelper.TABLE_CUSTOMER, null, cvCust);

            // Generate account number: ACC-00X
            Cursor cMax = db.rawQuery("SELECT COUNT(*) FROM " + DatabaseHelper.TABLE_ACCOUNT, null);
            int count = 0;
            if (cMax.moveToFirst()) {
                count = cMax.getInt(0);
            }
            cMax.close();
            String accountNumber = String.format(Locale.US, "ACC-%03d", count + 1);

            // Insert account
            ContentValues cvAcc = new ContentValues();
            cvAcc.put("customer_id", customerId);
            cvAcc.put("account_number", accountNumber);
            cvAcc.put("account_type", accType);
            cvAcc.put("balance", initialDeposit);
            cvAcc.put("status", "Active");
            long accountId = db.insert(DatabaseHelper.TABLE_ACCOUNT, null, cvAcc);

            // Insert initial deposit transaction
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            ContentValues cvTx = new ContentValues();
            cvTx.put("account_id", accountId);
            cvTx.put("transaction_type", "Deposit");
            cvTx.put("amount", initialDeposit);
            cvTx.put("transaction_date", dateFormat.format(new Date()));
            cvTx.put("transaction_time", timeFormat.format(new Date()));
            cvTx.put("notes", "Initial Deposit on Registration");
            db.insert(DatabaseHelper.TABLE_TRANSACTIONS, null, cvTx);

            db.setTransactionSuccessful();
            db.endTransaction();

            showSuccessDialog(accountNumber);
        } catch (Exception e) {
            db.endTransaction();
            Toast.makeText(this, "Error saving customer: " + e.getMessage(), Toast.LENGTH_LONG).show();
            btnSave.setEnabled(true);
        }
    }

    private void showSuccessDialog(String accountNumber) {
        new AlertDialog.Builder(this)
                .setTitle("Customer Registered Successfully")
                .setMessage("New account created successfully.\nAccount Number: " + accountNumber)
                .setPositiveButton("OK", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
    }
}