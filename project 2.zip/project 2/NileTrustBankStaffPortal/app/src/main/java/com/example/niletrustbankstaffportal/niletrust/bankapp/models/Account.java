package com.niletrust.bankapp.models;

public class Account {
    private int accountId;
    private int customerId;
    private String accountNumber;
    private String accountType;
    private double balance;
    private String status;
    private String customerName;

    public Account(int accountId, int customerId, String accountNumber, String accountType, double balance, String status, String customerName) {
        this.accountId = accountId;
        this.customerId = customerId;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.balance = balance;
        this.status = status;
        this.customerName = customerName;
    }

    public int getAccountId() { return accountId; }
    public int getCustomerId() { return customerId; }
    public String getAccountNumber() { return accountNumber; }
    public String getAccountType() { return accountType; }
    public double getBalance() { return balance; }
    public String getStatus() { return status; }
    public String getCustomerName() { return customerName; }
}