package com.niletrust.bankapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.chip.Chip;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.niletrust.bankapp.adapters.TransactionAdapter;
import com.niletrust.bankapp.models.TransactionItem;
import java.util.ArrayList;
import java.util.List;

public class CustomerDetailsActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private TextView tvNameDetail, tvAccNoDetail, tvNatIdDetail, tvAgeDetail, tvBalanceDetail;
    private Chip chipStatusDetail;
    private TextInputLayout tilEditPhone, tilEditAddress;
    private TextInputEditText etEditPhone, etEditAddress;
    private Button btnUpdate, btnCloseAccount;
    private RecyclerView recyclerViewTx;
    private DatabaseHelper dbHelper;

    private int customerId;
    private int accountId;
    private List<TransactionItem> transactionList;
    private TransactionAdapter txAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_details);

        dbHelper = new DatabaseHelper(this);
        customerId = getIntent().getIntExtra("CUSTOMER_ID", -1);
        accountId = getIntent().getIntExtra("ACCOUNT_ID", -1);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Customer Details");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        tvNameDetail = findViewById(R.id.tvNameDetail);
        tvAccNoDetail = findViewById(R.id.tvAccNoDetail);
        tvNatIdDetail = findViewById(R.id.tvNatIdDetail);
        tvAgeDetail = findViewById(R.id.tvAgeDetail);
        tvBalanceDetail = findViewById(R.id.tvBalanceDetail);
        chipStatusDetail = findViewById(R.id.chipStatusDetail);

        tilEditPhone = findViewById(R.id.tilEditPhone);
        tilEditAddress = findViewById(R.id.tilEditAddress);
        etEditPhone = findViewById(R.id.etEditPhone);
        etEditAddress = findViewById(R.id.etEditAddress);

        btnUpdate = findViewById(R.id.btnUpdateDetails);
        btnCloseAccount = findViewById(R.id.btnCloseAccount);

        recyclerViewTx = findViewById(R.id.recyclerViewTransactions);
        recyclerViewTx.setLayoutManager(new LinearLayoutManager(this));
        transactionList = new ArrayList<>();
        txAdapter = new TransactionAdapter(transactionList);
        recyclerViewTx.setAdapter(txAdapter);

        loadCustomerDetails();

        btnUpdate.setOnClickListener(v -> updateCustomerDetails());
        btnCloseAccount.setOnClickListener(v -> confirmCloseAccount());
    }

    private void loadCustomerDetails() {
        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String sql = "SELECT c.full_name, c.national_id, c.age, c.phone_number, c.address, " +
                    "a.account_number, a.balance, a.status " +
                    "FROM customer c JOIN account a ON c.customer_id = a.customer_id " +
                    "WHERE c.customer_id = ? AND a.account_id = ?";
            Cursor cursor = db.rawQuery(sql, new String[]{String.valueOf(customerId), String.valueOf(accountId)});

            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0);
                String natId = cursor.getString(1);
                int age = cursor.getInt(2);
                String phone = cursor.getString(3);
                String address = cursor.getString(4);
                String accNo = cursor.getString(5);
                double balance = cursor.getDouble(6);
                String status = cursor.getString(7);
                cursor.close();

                tvNameDetail.setText(name);
                tvAccNoDetail.setText(accNo + " (" + cursorGetStringSafe(cursor, 7, "Savings") + ")");
                tvNatIdDetail.setText("National ID: " + natId);
                tvAgeDetail.setText("Age: " + age);
                tvBalanceDetail.setText(DatabaseHelper.formatUgx(balance));

                etEditPhone.setText(phone);
                etEditAddress.setText(address);

                chipStatusDetail.setText(status);
                if ("Active".equalsIgnoreCase(status)) {
                    chipStatusDetail.setChipBackgroundColorResource(android.R.color.holo_green_light);
                    btnCloseAccount.setEnabled(true);
                } else {
                    chipStatusDetail.setChipBackgroundColorResource(android.R.color.darker_gray);
                    btnCloseAccount.setEnabled(false);
                    btnCloseAccount.setText("Account Closed");
                }
            }

            // Load transactions (newest first)
            transactionList.clear();
            Cursor cTx = db.rawQuery("SELECT transaction_id, transaction_type, amount, transaction_date, transaction_time, notes " +
                    "FROM transactions WHERE account_id = ? ORDER BY transaction_id DESC", new String[]{String.valueOf(accountId)});
            if (cTx != null && cTx.moveToFirst()) {
                do {
                    int txId = cTx.getInt(0);
                    String type = cTx.getString(1);
                    double amt = cTx.getDouble(2);
                    String date = cTx.getString(3);
                    String time = cTx.getString(4);
                    String notes = cTx.getString(5);
                    transactionList.add(new TransactionItem(txId, type, amt, date, time, notes));
                } while (cTx.moveToNext());
                cTx.close();
            }
            txAdapter.notifyDataSetChanged();

        } catch (Exception e) {
            Toast.makeText(this, "Error loading details", Toast.LENGTH_SHORT).show();
        }
    }

    private String cursorGetStringSafe(Cursor c, int idx, String defaultVal) {
        try {
            return c.getString(idx);
        } catch (Exception e) {
            return defaultVal;
        }
    }

    private void updateCustomerDetails() {
        String phone = etEditPhone.getText() != null ? etEditPhone.getText().toString().trim() : "";
        String address = etEditAddress.getText() != null ? etEditAddress.getText().toString().trim() : "";

        boolean hasError = false;
        if (phone.isEmpty()) {
            tilEditPhone.setError("Phone is required");
            hasError = true;
        } else if (!phone.matches("^(07\\d{8}|\\+2567\\d{8})$")) {
            tilEditPhone.setError("Format: 07XXXXXXXX or +2567XXXXXXXX");
            hasError = true;
        } else {
            tilEditPhone.setError(null);
        }

        if (address.isEmpty()) {
            tilEditAddress.setError("Address is required");
            hasError = true;
        } else {
            tilEditAddress.setError(null);
        }

        if (hasError) return;

        try {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("phone_number", phone);
            cv.put("address", address);
            db.update(DatabaseHelper.TABLE_CUSTOMER, cv, "customer_id = ?", new String[]{String.valueOf(customerId)});
            Toast.makeText(this, "Customer details updated successfully", Toast.LENGTH_SHORT).show();
            loadCustomerDetails();
        } catch (Exception e) {
            Toast.makeText(this, "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmCloseAccount() {
        new AlertDialog.Builder(this)
                .setTitle("Close Account")
                .setMessage("Are you sure you want to close this account? This action cannot be undone and will prevent future transactions.")
                .setPositiveButton("Close Account", (dialog, which) -> closeAccount())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void closeAccount() {
        try {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("status", "Closed");
            db.update(DatabaseHelper.TABLE_ACCOUNT, cv, "account_id = ?", new String[]{String.valueOf(accountId)});
            Toast.makeText(this, "Account closed successfully", Toast.LENGTH_SHORT).show();
            loadCustomerDetails();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to close account", Toast.LENGTH_SHORT).show();
        }
    }
}