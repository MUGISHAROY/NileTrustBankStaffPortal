package com.niletrust.bankapp.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.chip.Chip;
import com.niletrust.bankapp.DatabaseHelper;
import com.niletrust.bankapp.R;
import com.niletrust.bankapp.models.Customer;
import java.util.List;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.CustomerViewHolder> {
    private List<Customer> customerList;
    private OnCustomerClickListener listener;

    public interface OnCustomerClickListener {
        void onCustomerClick(Customer customer);
    }

    public CustomerAdapter(List<Customer> customerList, OnCustomerClickListener listener) {
        this.customerList = customerList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CustomerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_customer, parent, false);
        return new CustomerViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomerViewHolder holder, int position) {
        Customer customer = customerList.get(position);
        holder.tvName.setText(customer.getFullName());
        holder.tvAccountNo.setText(customer.getAccountNumber());
        holder.tvBalance.setText(DatabaseHelper.formatUgx(customer.getBalance()));

        String initial = customer.getFullName() != null && !customer.getFullName().isEmpty()
                ? customer.getFullName().substring(0, 1).toUpperCase() : "?";
        holder.tvAvatar.setText(initial);

        holder.chipStatus.setText(customer.getStatus());
        if ("Active".equalsIgnoreCase(customer.getStatus())) {
            holder.chipStatus.setChipBackgroundColorResource(android.R.color.holo_green_light);
            holder.chipStatus.setTextColor(Color.parseColor("#0A2540"));
        } else {
            holder.chipStatus.setChipBackgroundColorResource(android.R.color.darker_gray);
            holder.chipStatus.setTextColor(Color.WHITE);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onCustomerClick(customer);
        });
    }

    @Override
    public int getItemCount() {
        return customerList.size();
    }

    public void updateList(List<Customer> newList) {
        this.customerList = newList;
        notifyDataSetChanged();
    }

    static class CustomerViewHolder extends RecyclerView.ViewHolder {
        TextView tvAvatar, tvName, tvAccountNo, tvBalance;
        Chip chipStatus;

        public CustomerViewHolder(@NonNull View itemView) {
            super(itemView);
            tvAvatar = itemView.findViewById(R.id.tvAvatar);
            tvName = itemView.findViewById(R.id.tvName);
            tvAccountNo = itemView.findViewById(R.id.tvAccountNo);
            tvBalance = itemView.findViewById(R.id.tvBalance);
            chipStatus = itemView.findViewById(R.id.chipStatus);
        }
    }
}