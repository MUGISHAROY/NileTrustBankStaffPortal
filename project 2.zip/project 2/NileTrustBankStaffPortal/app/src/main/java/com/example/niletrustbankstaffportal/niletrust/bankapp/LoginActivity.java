package com.niletrust.bankapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity {
    private TextInputLayout tilUsername, tilPassword;
    private TextInputEditText etUsername, etPassword;
    private Button btnLogin;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);

        tilUsername = findViewById(R.id.tilUsername);
        tilPassword = findViewById(R.id.tilPassword);
        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        String username = etUsername.getText() != null ? etUsername.getText().toString().trim() : "";
        String password = etPassword.getText() != null ? etPassword.getText().toString().trim() : "";

        boolean hasError = false;
        if (username.isEmpty()) {
            tilUsername.setError("Username cannot be empty");
            hasError = true;
        } else {
            tilUsername.setError(null);
        }

        if (password.isEmpty()) {
            tilPassword.setError("Password cannot be empty");
            hasError = true;
        } else {
            tilPassword.setError(null);
        }

        if (hasError) return;

        btnLogin.setEnabled(false);
        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String hashedInput = DatabaseHelper.hashPassword(password);
            Cursor cursor = db.rawQuery("SELECT full_name, role FROM staff WHERE username = ? AND password_hash = ?", new String[]{username, hashedInput});

            if (cursor != null && cursor.moveToFirst()) {
                String fullName = cursor.getString(0);
                String role = cursor.getString(1);
                cursor.close();

                Toast.makeText(this, "Welcome, " + fullName, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(LoginActivity.this, MainMenuActivity.class);
                intent.putExtra("STAFF_NAME", fullName);
                intent.putExtra("STAFF_ROLE", role);
                startActivity(intent);
                finish();
            } else {
                if (cursor != null) cursor.close();
                Toast.makeText(this, "Invalid username or password", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Database error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            btnLogin.setEnabled(true);
        }
    }
}