package com.niletrust.bankapp.models;

public class Customer {
    private int customerId;
    private int accountId;
    private String nationalId;
    private String fullName;
    private int age;
    private String phoneNumber;
    private String address;
    private String accountNumber;
    private String accountType;
    private double balance;
    private String status;

    public Customer(int customerId, int accountId, String nationalId, String fullName, int age, String phoneNumber, String address, String accountNumber, String accountType, double balance, String status) {
        this.customerId = customerId;
        this.accountId = accountId;
        this.nationalId = nationalId;
        this.fullName = fullName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.accountNumber = accountNumber;
        this.accountType = accountType;
        this.balance = balance;
        this.status = status;
    }

    public int getCustomerId() { return customerId; }
    public int getAccountId() { return accountId; }
    public String getNationalId() { return nationalId; }
    public String getFullName() { return fullName; }
    public int getAge() { return age; }
    public String getPhoneNumber() { return phoneNumber; }
    public String getAddress() { return address; }
    public String getAccountNumber() { return accountNumber; }
    public String getAccountType() { return accountType; }
    public double getBalance() { return balance; }
    public String getStatus() { return status; }
}