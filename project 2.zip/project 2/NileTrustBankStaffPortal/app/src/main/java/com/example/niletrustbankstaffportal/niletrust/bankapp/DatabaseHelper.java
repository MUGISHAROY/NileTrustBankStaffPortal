package com.niletrust.bankapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "niletrust_bank.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_STAFF = "staff";
    public static final String TABLE_CUSTOMER = "customer";
    public static final String TABLE_ACCOUNT = "account";
    public static final String TABLE_TRANSACTIONS = "transactions";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createStaff = "CREATE TABLE " + TABLE_STAFF + " (" +
                "staff_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE NOT NULL, " +
                "password_hash TEXT NOT NULL, " +
                "full_name TEXT, " +
                "role TEXT)";

        String createCustomer = "CREATE TABLE " + TABLE_CUSTOMER + " (" +
                "customer_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "national_id TEXT UNIQUE NOT NULL, " +
                "full_name TEXT NOT NULL, " +
                "age INTEGER, " +
                "phone_number TEXT, " +
                "address TEXT)";

        String createAccount = "CREATE TABLE " + TABLE_ACCOUNT + " (" +
                "account_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "customer_id INTEGER NOT NULL, " +
                "account_number TEXT UNIQUE NOT NULL, " +
                "account_type TEXT, " +
                "balance REAL, " +
                "status TEXT DEFAULT 'Active', " +
                "FOREIGN KEY(customer_id) REFERENCES customer(customer_id))";

        String createTransactions = "CREATE TABLE " + TABLE_TRANSACTIONS + " (" +
                "transaction_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "account_id INTEGER NOT NULL, " +
                "transaction_type TEXT, " +
                "amount REAL, " +
                "transaction_date TEXT, " +
                "transaction_time TEXT, " +
                "notes TEXT, " +
                "FOREIGN KEY(account_id) REFERENCES account(account_id))";

        db.execSQL(createStaff);
        db.execSQL(createCustomer);
        db.execSQL(createAccount);
        db.execSQL(createTransactions);

        seedInitialData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TRANSACTIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ACCOUNT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CUSTOMER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STAFF);
        onCreate(db);
    }

    private void seedInitialData(SQLiteDatabase db) {
        // Seed default staff: teller1 / Bank@2026
        ContentValues staffValues = new ContentValues();
        staffValues.put("username", "teller1");
        staffValues.put("password_hash", hashPassword("Bank@2026"));
        staffValues.put("full_name", "Allan Mukasa");
        staffValues.put("role", "Senior Teller");
        db.insert(TABLE_STAFF, null, staffValues);

        // Seed 4 sample Ugandan customers
        insertSampleCustomer(db, "CM98012345ABCD", "Grace Namubiru", 28, "0772123456", "Kampala Road", "ACC-001", "Savings", 1250000.0, "Deposit", 1250000.0, "Initial Deposit");
        insertSampleCustomer(db, "CM98012345EFGH", "Ronald Okello", 35, "0783987654", "Jinja Main St", "ACC-002", "Current", 3400000.0, "Deposit", 3400000.0, "Opening Balance");
        insertSampleCustomer(db, "CM98012345IJKL", "Aisha Nakato", 24, "0701112233", "Entebbe Rd", "ACC-003", "Savings", 750000.0, "Deposit", 750000.0, "Initial Deposit");
        insertSampleCustomer(db, "CM98012345MNOP", "David Kigozi", 42, "0752445566", "Mbarara High St", "ACC-004", "Current", 5200000.0, "Deposit", 5200000.0, "Corporate Deposit");
    }

    private void insertSampleCustomer(SQLiteDatabase db, String natId, String name, int age, String phone, String addr, String accNo, String accType, double balance, String txType, double txAmount, String notes) {
        ContentValues cv = new ContentValues();
        cv.put("national_id", natId);
        cv.put("full_name", name);
        cv.put("age", age);
        cv.put("phone_number", phone);
        cv.put("address", addr);
        long custId = db.insert(TABLE_CUSTOMER, null, cv);

        ContentValues av = new ContentValues();
        av.put("customer_id", custId);
        av.put("account_number", accNo);
        av.put("account_type", accType);
        av.put("balance", balance);
        av.put("status", "Active");
        long accId = db.insert(TABLE_ACCOUNT, null, av);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        String dateStr = dateFormat.format(new Date());
        String timeStr = timeFormat.format(new Date());

        ContentValues tv = new ContentValues();
        tv.put("account_id", accId);
        tv.put("transaction_type", txType);
        tv.put("amount", txAmount);
        tv.put("transaction_date", dateStr);
        tv.put("transaction_time", timeStr);
        tv.put("notes", notes);
        db.insert(TABLE_TRANSACTIONS, null, tv);
    }

    public static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            return password;
        }
    }

    public static String formatUgx(double amount) {
        return String.format(Locale.US, "UGX %,.0f", amount);
    }
}