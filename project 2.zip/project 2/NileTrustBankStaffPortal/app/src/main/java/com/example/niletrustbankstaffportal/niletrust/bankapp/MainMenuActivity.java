package com.niletrust.bankapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainMenuActivity extends AppCompatActivity {
    private TextView tvGreeting, tvTotalCustomers, tvTotalBalance;
    private CardView cardCustomers, cardRegister, cardTransactions, cardLogout;
    private DatabaseHelper dbHelper;
    private String staffName, staffRole;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        dbHelper = new DatabaseHelper(this);
        staffName = getIntent().getStringExtra("STAFF_NAME");
        if (staffName == null) staffName = "Staff Member";
        staffRole = getIntent().getStringExtra("STAFF_ROLE");
        if (staffRole == null) staffRole = "Teller";

        tvGreeting = findViewById(R.id.tvGreeting);
        tvTotalCustomers = findViewById(R.id.tvTotalCustomers);
        tvTotalBalance = findViewById(R.id.tvTotalBalance);
        cardCustomers = findViewById(R.id.cardCustomers);
        cardRegister = findViewById(R.id.cardRegister);
        cardTransactions = findViewById(R.id.cardTransactions);
        cardLogout = findViewById(R.id.cardLogout);

        tvGreeting.setText("Welcome, " + staffName + " (" + staffRole + ")");

        cardCustomers.setOnClickListener(v -> startActivity(new Intent(MainMenuActivity.this, CustomerListActivity.class)));
        cardRegister.setOnClickListener(v -> startActivity(new Intent(MainMenuActivity.this, RegisterCustomerActivity.class)));
        cardTransactions.setOnClickListener(v -> startActivity(new Intent(MainMenuActivity.this, TransactionActivity.class)));
        cardLogout.setOnClickListener(v -> {
            Intent intent = new Intent(MainMenuActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadSummaryStats();
    }

    private void loadSummaryStats() {
        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            Cursor cCust = db.rawQuery("SELECT COUNT(*) FROM " + DatabaseHelper.TABLE_CUSTOMER, null);
            int totalCust = 0;
            if (cCust.moveToFirst()) {
                totalCust = cCust.getInt(0);
            }
            cCust.close();

            Cursor cBal = db.rawQuery("SELECT SUM(balance) FROM " + DatabaseHelper.TABLE_ACCOUNT + " WHERE status = 'Active'", null);
            double totalBal = 0.0;
            if (cBal.moveToFirst()) {
                totalBal = cBal.getDouble(0);
            }
            cBal.close();

            tvTotalCustomers.setText(String.valueOf(totalCust));
            tvTotalBalance.setText(DatabaseHelper.formatUgx(totalBal));
        } catch (Exception e) {
            Toast.makeText(this, "Error loading stats", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onBackPressed() {
        // Prevent going back to Login screen from Main Menu
        finish();
    }
}