package com.niletrust.bankapp.models;

public class TransactionItem {
    private int transactionId;
    private String transactionType;
    private double amount;
    private String date;
    private String time;
    private String notes;

    public TransactionItem(int transactionId, String transactionType, double amount, String date, String time, String notes) {
        this.transactionId = transactionId;
        this.transactionType = transactionType;
        this.amount = amount;
        this.date = date;
        this.time = time;
        this.notes = notes;
    }

    public int getTransactionId() { return transactionId; }
    public String getTransactionType() { return transactionType; }
    public double getAmount() { return amount; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getNotes() { return notes; }
}