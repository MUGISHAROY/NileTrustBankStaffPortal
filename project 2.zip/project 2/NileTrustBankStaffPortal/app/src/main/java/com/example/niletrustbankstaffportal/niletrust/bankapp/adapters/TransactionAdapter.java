package com.niletrust.bankapp.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.niletrust.bankapp.DatabaseHelper;
import com.niletrust.bankapp.R;
import com.niletrust.bankapp.models.TransactionItem;
import java.util.List;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {
    private List<TransactionItem> transactionList;

    public TransactionAdapter(List<TransactionItem> transactionList) {
        this.transactionList = transactionList;
    }

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
        return new TransactionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        TransactionItem item = transactionList.get(position);
        holder.tvType.setText(item.getTransactionType());
        holder.tvDateTime.setText(item.getDate() + " " + item.getTime());
        holder.tvNotes.setText(item.getNotes() != null && !item.getNotes().isEmpty() ? item.getNotes() : "No notes");

        String type = item.getTransactionType();
        if ("Deposit".equalsIgnoreCase(type)) {
            holder.tvAmount.setText("+" + DatabaseHelper.formatUgx(item.getAmount()));
            holder.tvAmount.setTextColor(Color.parseColor("#00A878"));
        } else if ("Withdrawal".equalsIgnoreCase(type)) {
            holder.tvAmount.setText("-" + DatabaseHelper.formatUgx(item.getAmount()));
            holder.tvAmount.setTextColor(Color.parseColor("#D64545"));
        } else {
            // Transfer
            holder.tvAmount.setText(DatabaseHelper.formatUgx(item.getAmount()));
            holder.tvAmount.setTextColor(Color.parseColor("#0A2540"));
        }
    }

    @Override
    public int getItemCount() {
        return transactionList.size();
    }

    static class TransactionViewHolder extends RecyclerView.ViewHolder {
        TextView tvType, tvDateTime, tvNotes, tvAmount;

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            tvType = itemView.findViewById(R.id.tvTxType);
            tvDateTime = itemView.findViewById(R.id.tvTxDateTime);
            tvNotes = itemView.findViewById(R.id.tvTxNotes);
            tvAmount = itemView.findViewById(R.id.tvTxAmount);
        }
    }
}