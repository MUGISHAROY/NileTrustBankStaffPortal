package com.niletrust.bankapp;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TransactionActivity extends AppCompatActivity {
    private Toolbar toolbar;
    private TextInputLayout tilAccountNo, tilDestAccount, tilAmount, tilNotes;
    private TextInputEditText etAccountNo, etDestAccount, etAmount, etNotes;
    private AutoCompleteTextView actTxType;
    private LinearLayout layoutAccountInfo;
    private TextView tvCustomerNameInfo, tvCurrentBalanceInfo;
    private Button btnProcess;
    private DatabaseHelper dbHelper;

    private int lookupAccountId = -1;
    private double lookupCurrentBalance = 0.0;
    private String lookupAccountStatus = "";
    private int lookupDestAccountId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);

        dbHelper = new DatabaseHelper(this);

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Process Transaction");
        }
        toolbar.setNavigationOnClickListener(v -> onBackPressed());

        tilAccountNo = findViewById(R.id.tilAccountNo);
        tilDestAccount = findViewById(R.id.tilDestAccount);
        tilAmount = findViewById(R.id.tilAmount);
        tilNotes = findViewById(R.id.tilNotes);

        etAccountNo = findViewById(R.id.etAccountNo);
        etDestAccount = findViewById(R.id.etDestAccount);
        etAmount = findViewById(R.id.etAmount);
        etNotes = findViewById(R.id.etNotes);
        actTxType = findViewById(R.id.actTxType);

        layoutAccountInfo = findViewById(R.id.layoutAccountInfo);
        tvCustomerNameInfo = findViewById(R.id.tvCustomerNameInfo);
        tvCurrentBalanceInfo = findViewById(R.id.tvCurrentBalanceInfo);
        btnProcess = findViewById(R.id.btnProcessTransaction);

        String[] txTypes = new String[]{"Deposit", "Withdrawal", "Transfer"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, txTypes);
        actTxType.setAdapter(adapter);
        actTxType.setText("Deposit", false);

        // Hide/Show destination account based on transaction type
        actTxType.setOnItemClickListener((parent, view, position, id) -> {
            String selected = (String) parent.getItemAtPosition(position);
            if ("Transfer".equals(selected)) {
                tilDestAccount.setVisibility(View.VISIBLE);
            } else {
                tilDestAccount.setVisibility(View.GONE);
                etDestAccount.setText("");
            }
        });

        // Real-time account lookup as user types account number
        etAccountNo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                lookupAccount(s.toString().trim());
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnProcess.setOnClickListener(v -> confirmAndProcessTransaction());
    }

    private void lookupAccount(String accountNo) {
        if (accountNo.isEmpty()) {
            layoutAccountInfo.setVisibility(View.GONE);
            lookupAccountId = -1;
            return;
        }

        try {
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            String sql = "SELECT a.account_id, a.balance, a.status, c.full_name " +
                    "FROM account a JOIN customer c ON a.customer_id = c.customer_id " +
                    "WHERE a.account_number = ?";
            Cursor cursor = db.rawQuery(sql, new String[]{accountNo});

            if (cursor != null && cursor.moveToFirst()) {
                lookupAccountId = cursor.getInt(0);
                lookupCurrentBalance = cursor.getDouble(1);
                lookupAccountStatus = cursor.getString(2);
                String customerName = cursor.getString(3);
                cursor.close();

                tvCustomerNameInfo.setText("Customer: " + customerName);
                tvCurrentBalanceInfo.setText("Balance: " + DatabaseHelper.formatUgx(lookupCurrentBalance) + " (" + lookupAccountStatus + ")");
                layoutAccountInfo.setVisibility(View.VISIBLE);
            } else {
                if (cursor != null) cursor.close();
                layoutAccountInfo.setVisibility(View.GONE);
                lookupAccountId = -1;
            }
        } catch (Exception e) {
            layoutAccountInfo.setVisibility(View.GONE);
            lookupAccountId = -1;
        }
    }

    private void confirmAndProcessTransaction() {
        String accNo = etAccountNo.getText() != null ? etAccountNo.getText().toString().trim() : "";
        String destAccNo = etDestAccount.getText() != null ? etDestAccount.getText().toString().trim() : "";
        String amountStr = etAmount.getText() != null ? etAmount.getText().toString().trim() : "";
        String txType = actTxType.getText().toString();
        String notes = etNotes.getText() != null ? etNotes.getText().toString().trim() : "";

        boolean hasError = false;

        if (accNo.isEmpty()) {
            tilAccountNo.setError("Account number is required");
            hasError = true;
        } else {
            tilAccountNo.setError(null);
        }

        if (lookupAccountId == -1) {
            tilAccountNo.setError("Account does not exist");
            hasError = true;
        } else if ("Closed".equalsIgnoreCase(lookupAccountStatus)) {
            tilAccountNo.setError("Cannot transact on a Closed account");
            hasError = true;
        }

        if ("Transfer".equals(txType)) {
            if (destAccNo.isEmpty()) {
                tilDestAccount.setError("Destination account is required");
                hasError = true;
            } else if (destAccNo.equals(accNo)) {
                tilDestAccount.setError("Cannot transfer to the same account");
                hasError = true;
            } else {
                tilDestAccount.setError(null);
            }
        }

        double amount = 0;
        if (amountStr.isEmpty()) {
            tilAmount.setError("Amount is required");
            hasError = true;
        } else {
            try {
                amount = Double.parseDouble(amountStr);
                if (amount <= 0) {
                    tilAmount.setError("Amount must be greater than 0");
                    hasError = true;
                } else if (("Withdrawal".equals(txType) || "Transfer".equals(txType)) && amount > lookupCurrentBalance) {
                    tilAmount.setError("Insufficient funds. Available: " + DatabaseHelper.formatUgx(lookupCurrentBalance));
                    hasError = true;
                } else {
                    tilAmount.setError(null);
                }
            } catch (NumberFormatException e) {
                tilAmount.setError("Invalid amount");
                hasError = true;
            }
        }

        if (hasError) return;

        // If transfer, verify destination account exists and is active
        if ("Transfer".equals(txType)) {
            try {
                SQLiteDatabase db = dbHelper.getReadableDatabase();
                Cursor cDest = db.rawQuery("SELECT account_id, status FROM account WHERE account_number = ?", new String[]{destAccNo});
                if (cDest != null && cDest.moveToFirst()) {
                    lookupDestAccountId = cDest.getInt(0);
                    String destStatus = cDest.getString(1);
                    cDest.close();
                    if ("Closed".equalsIgnoreCase(destStatus)) {
                        tilDestAccount.setError("Destination account is Closed");
                        return;
                    }
                } else {
                    if (cDest != null) cDest.close();
                    tilDestAccount.setError("Destination account does not exist");
                    return;
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error verifying destination account", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        final double finalAmount = amount;
        new AlertDialog.Builder(this)
                .setTitle("Confirm Transaction")
                .setMessage("Process " + txType + " of " + DatabaseHelper.formatUgx(finalAmount) + " for account " + accNo + "?")
                .setPositiveButton("Confirm", (dialog, which) -> executeTransaction(txType, finalAmount, notes))
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void executeTransaction(String txType, double amount, String notes) {
        btnProcess.setEnabled(false);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.beginTransaction();
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            String dateStr = dateFormat.format(new Date());
            String timeStr = timeFormat.format(new Date());

            if ("Deposit".equals(txType)) {
                double newBalance = lookupCurrentBalance + amount;
                db.execSQL("UPDATE account SET balance = ? WHERE account_id = ?", new Object[]{newBalance, lookupAccountId});

                ContentValues cv = new ContentValues();
                cv.put("account_id", lookupAccountId);
                cv.put("transaction_type", "Deposit");
                cv.put("amount", amount);
                cv.put("transaction_date", dateStr);
                cv.put("transaction_time", timeStr);
                cv.put("notes", notes.isEmpty() ? "Cash Deposit" : notes);
                db.insert(DatabaseHelper.TABLE_TRANSACTIONS, null, cv);

                db.setTransactionSuccessful();
                db.endTransaction();
                showSuccessMessage(newBalance);

            } else if ("Withdrawal".equals(txType)) {
                double newBalance = lookupCurrentBalance - amount;
                db.execSQL("UPDATE account SET balance = ? WHERE account_id = ?", new Object[]{newBalance, lookupAccountId});

                ContentValues cv = new ContentValues();
                cv.put("account_id", lookupAccountId);
                cv.put("transaction_type", "Withdrawal");
                cv.put("amount", amount);
                cv.put("transaction_date", dateStr);
                cv.put("transaction_time", timeStr);
                cv.put("notes", notes.isEmpty() ? "Cash Withdrawal" : notes);
                db.insert(DatabaseHelper.TABLE_TRANSACTIONS, null, cv);

                db.setTransactionSuccessful();
                db.endTransaction();
                showSuccessMessage(newBalance);

            } else if ("Transfer".equals(txType)) {
                // Deduct from sender
                double newSenderBalance = lookupCurrentBalance - amount;
                db.execSQL("UPDATE account SET balance = ? WHERE account_id = ?", new Object[]{newSenderBalance, lookupAccountId});

                ContentValues cvSender = new ContentValues();
                cvSender.put("account_id", lookupAccountId);
                cvSender.put("transaction_type", "Transfer (Out)");
                cvSender.put("amount", amount);
                cvSender.put("transaction_date", dateStr);
                cvSender.put("transaction_time", timeStr);
                cvSender.put("notes", notes.isEmpty() ? "Transfer to " + etDestAccount.getText().toString() : notes);
                db.insert(DatabaseHelper.TABLE_TRANSACTIONS, null, cvSender);

                // Add to receiver
                Cursor cDestBal = db.rawQuery("SELECT balance FROM account WHERE account_id = ?", new String[]{String.valueOf(lookupDestAccountId)});
                double destCurrentBal = 0.0;
                if (cDestBal.moveToFirst()) {
                    destCurrentBal = cDestBal.getDouble(0);
                }
                cDestBal.close();

                double newDestBalance = destCurrentBal + amount;
                db.execSQL("UPDATE account SET balance = ? WHERE account_id = ?", new Object[]{newDestBalance, lookupDestAccountId});

                ContentValues cvDest = new ContentValues();
                cvDest.put("account_id", lookupDestAccountId);
                cvDest.put("transaction_type", "Transfer (In)");
                cvDest.put("amount", amount);
                cvDest.put("transaction_date", dateStr);
                cvDest.put("transaction_time", timeStr);
                cvDest.put("notes", notes.isEmpty() ? "Transfer from " + etAccountNo.getText().toString() : notes);
                db.insert(DatabaseHelper.TABLE_TRANSACTIONS, null, cvDest);

                db.setTransactionSuccessful();
                db.endTransaction();
                showSuccessMessage(newSenderBalance);
            }
        } catch (Exception e) {
            db.endTransaction();
            Toast.makeText(this, "Transaction failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            btnProcess.setEnabled(true);
        }
    }

    private void showSuccessMessage(double newBalance) {
        new AlertDialog.Builder(this)
                .setTitle("Transaction Successful")
                .setMessage("Transaction completed successfully.\nNew Balance: " + DatabaseHelper.formatUgx(newBalance))
                .setPositiveButton("OK", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
    }
}